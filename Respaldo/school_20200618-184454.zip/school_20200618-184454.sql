-- MySQL dump 10.13  Distrib 5.5.24, for Win32 (x86)
--
-- Host: localhost    Database: school
-- ------------------------------------------------------
-- Server version	5.5.24-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alumnos`
--

DROP TABLE IF EXISTS `alumnos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alumnos` (
  `id_alum` int(10) NOT NULL AUTO_INCREMENT,
  `name_alum` varchar(155) NOT NULL,
  `apell_alum` varchar(155) NOT NULL,
  `iden_alum` varchar(15) NOT NULL,
  `sexo_alum` varchar(155) NOT NULL,
  `peso_alum` varchar(15) NOT NULL,
  `talla_alum` varchar(15) NOT NULL,
  `email_alum` varchar(20) NOT NULL,
  `nac_alum` varchar(15) NOT NULL,
  `lugar_alum` varchar(55) NOT NULL,
  `estado_alum` varchar(55) NOT NULL,
  `nacionalidad_alum` varchar(55) NOT NULL,
  `direccion_alum` varchar(100) NOT NULL,
  `periodo_es` varchar(100) NOT NULL,
  `grado_es` varchar(100) NOT NULL,
  `inscripcion_es` varchar(100) NOT NULL,
  PRIMARY KEY (`id_alum`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumnos`
--

LOCK TABLES `alumnos` WRITE;
/*!40000 ALTER TABLE `alumnos` DISABLE KEYS */;
INSERT INTO `alumnos` VALUES (1,'ff','fff','fff','1','fff','fff','','2020-06-05','fff','fff','ff','fff','0','2','hhh'),(2,'ff','fff','fff','1','fff','fff','','2020-06-05','fff','fff','ff','fff','0','2','hhh'),(3,'ff','fff','fff','1','fff','fff','','2020-06-05','fff','fff','ff','fff','0','2','hhh'),(4,'Jose','Marin','333','1','12','22','','2020-06-05','bolivar','bolivar','venezolano','calle el zaj','0','1','jhjjj'),(5,'ddd','dd','ddd','1','55','55','','2020-06-05','jdjjd','dndnd','dndnnd','ddndn','2017-2019 ','1','ksksksk'),(6,'ddd','dd','ddd','1','55','55','','2020-06-05','jdjjd','dndnd','dndnnd','ddndn','2017-2019 ','1','ksksksk'),(7,'ddd','dd','ddd','1','55','55','','2020-06-05','jdjjd','dndnd','dndnnd','ddndn','2017-2019 ','1','ksksksk'),(8,'ddd','dd','ddd','1','55','55','','2020-06-05','jdjjd','dndnd','dndnnd','ddndn','2017-2019 ','1','ksksksk'),(9,'djjdjd','ddd','333','1','55','555','','2020-06-12','ddd','ddd','dddd','ddd','2017-2019 ','2','ffff'),(10,'djjdjd','ddd','333','1','55','555','','2020-06-12','ddd','ddd','dddd','ddd','2017-2019 ','2','ffff'),(11,'djjdjd','ddd','333','1','55','555','','2020-06-12','ddd','ddd','dddd','ddd','2017-2019 ','2','ffff'),(12,'ddd','dd','ddd','1','55','55','','2020-06-05','jdjjd','dndnd','dndnnd','ddndn','2017-2019 ','1','ksksksk'),(13,'djjdjd','ddd','333','1','55','555','','2020-06-12','ddd','ddd','dddd','ddd','2017-2019 ','2','ffff'),(14,'ddd','dd','ddd','1','55','55','','2020-06-05','jdjjd','dndnd','dndnnd','ddndn','2017-2019 ','1','ksksksk'),(15,'','','','','','','','','','','','','','',''),(16,'','','','','','','','','','','','','','',''),(17,'','','','','','','','','','','','','','','');
/*!40000 ALTER TABLE `alumnos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `docentes`
--

DROP TABLE IF EXISTS `docentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `docentes` (
  `id_doc` int(11) NOT NULL AUTO_INCREMENT,
  `cod_doc` varchar(10) NOT NULL,
  `cedu_d` varchar(20) NOT NULL,
  `cargo` varchar(255) NOT NULL,
  `name_d` varchar(55) NOT NULL,
  `apell_d` varchar(55) NOT NULL,
  `email_d` varchar(55) NOT NULL,
  `phone_d` int(55) NOT NULL,
  `direccion` varchar(55) NOT NULL,
  `date_n` varchar(100) NOT NULL,
  `date_i` varchar(100) NOT NULL,
  `sueldo` float NOT NULL,
  PRIMARY KEY (`id_doc`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `docentes`
--

LOCK TABLES `docentes` WRITE;
/*!40000 ALTER TABLE `docentes` DISABLE KEYS */;
INSERT INTO `docentes` VALUES (24,'4566','26048290','Aseador','jose','ramirez','',2147483647,'calle boyaca,  casa 2399','05/23/2020','05/01/2020',2000);
/*!40000 ALTER TABLE `docentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periodo_grado`
--

DROP TABLE IF EXISTS `periodo_grado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `periodo_grado` (
  `id_peri` int(10) NOT NULL AUTO_INCREMENT,
  `periodo_escolar` varchar(55) NOT NULL,
  PRIMARY KEY (`id_peri`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periodo_grado`
--

LOCK TABLES `periodo_grado` WRITE;
/*!40000 ALTER TABLE `periodo_grado` DISABLE KEYS */;
INSERT INTO `periodo_grado` VALUES (1,'2017-2019'),(2,'2017-2019'),(3,'2017-2019'),(4,''),(5,''),(6,'');
/*!40000 ALTER TABLE `periodo_grado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `representantes`
--

DROP TABLE IF EXISTS `representantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `representantes` (
  `id_represen` int(11) NOT NULL AUTO_INCREMENT,
  `name_m` varchar(55) NOT NULL,
  `cedula_m` varchar(55) NOT NULL,
  `civil_m` varchar(55) NOT NULL,
  `email_m` varchar(55) NOT NULL,
  `telefono_m` varchar(55) NOT NULL,
  `ocupacion_m` varchar(55) NOT NULL,
  `name_p` int(11) NOT NULL,
  `cedula_p` int(11) NOT NULL,
  `civil_p` int(11) NOT NULL,
  `email_p` varchar(55) NOT NULL,
  `telefono_p` varchar(55) NOT NULL,
  `ocupacion_p` varchar(55) NOT NULL,
  PRIMARY KEY (`id_represen`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `representantes`
--

LOCK TABLES `representantes` WRITE;
/*!40000 ALTER TABLE `representantes` DISABLE KEYS */;
INSERT INTO `representantes` VALUES (3,'ff','fff','1','fff','9999','',0,0,1,'mmmms','333','ddd'),(4,'ff','fff','1','fff','9999','',0,0,1,'mmmms','333','ddd'),(5,'ff','fff','1','fff','9999','',0,0,1,'mmmms','333','ddd'),(6,'maria diaz','222','1','moises@gmail.com','333','',0,333,1,'mo@gma','01010','jajja'),(7,'sjsjjs','sjsjsj','1','sjjsjs','388383','',0,82828,1,'sjjsjsj','2222','ajajja'),(8,'sjsjjs','sjsjsj','1','sjjsjs','388383','',0,82828,1,'sjjsjsj','2222','ajajja'),(9,'sjsjjs','sjsjsj','1','sjjsjs','388383','',0,82828,1,'sjjsjsj','2222','ajajja'),(10,'sjsjjs','sjsjsj','1','sjjsjs','388383','',0,82828,1,'sjjsjsj','2222','ajajja'),(11,'ddd','rrr','2','rrrr','7777','',777,0,3,'jjuuu','8888','888'),(12,'ddd','rrr','2','rrrr','7777','',777,0,3,'jjuuu','8888','888'),(13,'ddd','rrr','2','rrrr','7777','',777,0,3,'jjuuu','8888','888'),(14,'sjsjjs','sjsjsj','1','sjjsjs','388383','',0,82828,1,'sjjsjsj','2222','ajajja'),(15,'ddd','rrr','2','rrrr','7777','',777,0,3,'jjuuu','8888','888'),(16,'sjsjjs','sjsjsj','1','sjjsjs','388383','',0,82828,1,'sjjsjsj','2222','ajajja'),(17,'','','','','','',0,0,0,'','',''),(18,'','','','','','',0,0,0,'','',''),(19,'','','','','','',0,0,0,'','','');
/*!40000 ALTER TABLE `representantes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-18 14:44:57
