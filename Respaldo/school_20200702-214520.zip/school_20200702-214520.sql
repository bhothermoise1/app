-- MySQL dump 10.13  Distrib 5.5.24, for Win32 (x86)
--
-- Host: localhost    Database: school
-- ------------------------------------------------------
-- Server version	5.5.24-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alum_pres`
--

DROP TABLE IF EXISTS `alum_pres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alum_pres` (
  `id_pres` int(11) NOT NULL AUTO_INCREMENT,
  `name_pres` varchar(150) DEFAULT NULL,
  `sexo_pres` varchar(20) DEFAULT NULL,
  `edad_pres` varchar(20) DEFAULT NULL,
  `talla_pres` varchar(20) DEFAULT NULL,
  `peso_pres` varchar(20) DEFAULT NULL,
  `nacimient_pres` date DEFAULT NULL,
  `lugar_pres` varchar(100) DEFAULT NULL,
  `direccion_pres` varchar(150) DEFAULT NULL,
  `repre_pres` varchar(100) DEFAULT NULL,
  `cedula_pres` varchar(50) DEFAULT NULL,
  `civil_pres` varchar(60) DEFAULT NULL,
  `parentesco_pres` varchar(80) DEFAULT NULL,
  `correo_pres` varchar(100) DEFAULT NULL,
  `phone_pres` varchar(100) DEFAULT NULL,
  `ocupacion_pres` varchar(100) DEFAULT NULL,
  `question_1` varchar(80) DEFAULT NULL,
  `question_2` varchar(80) DEFAULT NULL,
  `question_3` varchar(80) DEFAULT NULL,
  `periodo_pres` varchar(80) DEFAULT NULL,
  `nivel_pres` varchar(80) DEFAULT NULL,
  `inscripcion_pres` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id_pres`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alum_pres`
--

LOCK TABLES `alum_pres` WRITE;
/*!40000 ALTER TABLE `alum_pres` DISABLE KEYS */;
/*!40000 ALTER TABLE `alum_pres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alumnos`
--

DROP TABLE IF EXISTS `alumnos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alumnos` (
  `id_alum` int(10) NOT NULL AUTO_INCREMENT,
  `name_alum` varchar(155) NOT NULL,
  `apell_alum` varchar(155) NOT NULL,
  `iden_alum` varchar(15) NOT NULL,
  `sexo_alum` varchar(155) NOT NULL,
  `peso_alum` varchar(15) NOT NULL,
  `talla_alum` varchar(15) NOT NULL,
  `nac_alum` varchar(15) NOT NULL,
  `lugar_alum` varchar(55) NOT NULL,
  `estado_alum` varchar(55) NOT NULL,
  `nacionalidad_alum` varchar(55) NOT NULL,
  `direccion_alum` varchar(100) NOT NULL,
  `periodo_es` varchar(100) NOT NULL,
  `grado_es` varchar(100) NOT NULL,
  `inscripcion_es` varchar(100) NOT NULL,
  `name_m` varchar(155) NOT NULL,
  `cedula_m` varchar(155) NOT NULL,
  `civil_m` varchar(155) NOT NULL,
  `parentesco_m` varchar(155) NOT NULL,
  `email_m` varchar(155) NOT NULL,
  `telefono_m` varchar(155) NOT NULL,
  `ocupacion_m` varchar(155) NOT NULL,
  PRIMARY KEY (`id_alum`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumnos`
--

LOCK TABLES `alumnos` WRITE;
/*!40000 ALTER TABLE `alumnos` DISABLE KEYS */;
INSERT INTO `alumnos` VALUES (22,'$nombre','$apellido','$identificacion','$sexo','$peso','$talla','$nacimiento','$lugar','$estado','$nacionalidad','$direccion','$periodo','$grado','$inscripcion','$name_m','$cedula_m','$civil_m','$parestesco','$correo_m','$phone_m','$ocupacion_m'),(23,'jose','martinez','2333','1','35','33','2020-06-25','Ciudad Piar','Bolivar','Venezolano','calle boyACA casa 56','2017-2019 ','1','27/10/89','Moises Leon','334444','4','Padre','moisesgdi@gmail.com','04147887003',''),(24,'eeeeeeeeeeeeeee','dd  ','ddd  ','Masculino','55  ','55  ','2020-06-05  ','jdjjd  ','dndnd  ','dndnnd  ','ddndn  ','periodo','Segundo Grado','ddd','gsgsg','555','0','55','55','555','');
/*!40000 ALTER TABLE `alumnos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `docentes`
--

DROP TABLE IF EXISTS `docentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `docentes` (
  `id_doc` int(11) NOT NULL AUTO_INCREMENT,
  `cod_doc` varchar(10) NOT NULL,
  `cedu_d` varchar(20) NOT NULL,
  `cargo` varchar(255) NOT NULL,
  `name_d` varchar(55) NOT NULL,
  `apell_d` varchar(55) NOT NULL,
  `email_d` varchar(55) NOT NULL,
  `phone_d` int(55) NOT NULL,
  `direccion` varchar(55) NOT NULL,
  `date_n` varchar(100) NOT NULL,
  `date_i` varchar(100) NOT NULL,
  `sexo_work` varchar(30) NOT NULL,
  PRIMARY KEY (`id_doc`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `docentes`
--

LOCK TABLES `docentes` WRITE;
/*!40000 ALTER TABLE `docentes` DISABLE KEYS */;
INSERT INTO `docentes` VALUES (24,'4566','26048290','Aseador','jose','ramirez','',2147483647,'calle boyaca,  casa 2399','05/23/2020','05/01/2020',''),(25,'$cod','$cedula','$cargo','$nombre','$apellido','$correo',0,'$direccion','$nacimiento','$ingreso','$sexo'),(26,'8887777777','555','555','xxx','xxx','555',555,'5555','2020-06-22','2020-06-22','0');
/*!40000 ALTER TABLE `docentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periodo_grado`
--

DROP TABLE IF EXISTS `periodo_grado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `periodo_grado` (
  `id_peri` int(10) NOT NULL AUTO_INCREMENT,
  `periodo_escolar` varchar(55) NOT NULL,
  PRIMARY KEY (`id_peri`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periodo_grado`
--

LOCK TABLES `periodo_grado` WRITE;
/*!40000 ALTER TABLE `periodo_grado` DISABLE KEYS */;
INSERT INTO `periodo_grado` VALUES (1,'2017-2019'),(2,'2017-2019'),(3,'2017-2019'),(4,''),(5,''),(6,'');
/*!40000 ALTER TABLE `periodo_grado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `representantes`
--

DROP TABLE IF EXISTS `representantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `representantes` (
  `id_represen` int(11) NOT NULL AUTO_INCREMENT,
  `name_m` varchar(55) NOT NULL,
  `cedula_m` varchar(55) NOT NULL,
  `civil_m` varchar(55) NOT NULL,
  `parentesco_m` varchar(155) NOT NULL,
  `email_m` varchar(55) NOT NULL,
  `telefono_m` varchar(55) NOT NULL,
  `ocupacion_m` varchar(55) NOT NULL,
  PRIMARY KEY (`id_represen`),
  CONSTRAINT `representantes_ibfk_1` FOREIGN KEY (`id_represen`) REFERENCES `alumnos` (`id_alum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `representantes`
--

LOCK TABLES `representantes` WRITE;
/*!40000 ALTER TABLE `representantes` DISABLE KEYS */;
/*!40000 ALTER TABLE `representantes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-02 17:45:22
